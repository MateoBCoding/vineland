<?php 
$conexion = new mysqli("localhost","root","","vineland","3306");
$conexion->set_charset("utf8");
