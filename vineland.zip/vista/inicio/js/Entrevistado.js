

document.getElementById("diossoyyo").addEventListener("click", function(event) {
      window.location.href= 'receptiva.php';
    });